//
//  Pizza.swift
//  PizzaApp
//
//  Created by Mac on 9/23/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

//enum topping:String {
//
//}

struct Pizza {
    var toppings:[String] = []
    init(toppings:[String]) {
        
    }
}
