//
//  MyChatFramework.h
//  MyChatFramework
//
//  Created by Mac on 9/28/17.
//  Copyright © 2017 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyChatFramework.
FOUNDATION_EXPORT double MyChatFrameworkVersionNumber;

//! Project version string for MyChatFramework.
FOUNDATION_EXPORT const unsigned char MyChatFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyChatFramework/PublicHeader.h>


